const mongoose = require('mongoose');

const TermsTemplateSchema = new mongoose.Schema({
    templateName: { type: String, required: true },
    categoryId: { type: mongoose.Schema.Types.ObjectId, ref: 'Category' },
    content: { type: String, required: true },
    isDefault: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now },
});

TermsTemplateSchema.index({ createdAt: -1 });
TermsTemplateSchema.index({ isDefault: 1, createdAt: -1 });

const tenantPlugin = require('./plugins/tenantPlugin');
TermsTemplateSchema.plugin(tenantPlugin);
module.exports = mongoose.model('TermsTemplate', TermsTemplateSchema);
